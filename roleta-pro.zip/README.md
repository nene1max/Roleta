# 🎰 Roleta Pro

**Roleta Pro** é um aplicativo web inteligente que analisa partidas de roleta ao vivo (Bet365) e identifica padrões estatísticos para ajudar o usuário a tomar decisões mais informadas.

> ✅ Foco: Cores, Par/Ímpar, Dúzias, Colunas e Setores (Tier, Voisins, Orphelins, Zero)

---

## 🔍 Funcionalidades

- 📊 Análise em tempo real de cores (vermelho, preto, verde)
- 🔢 Detecção de padrões de par e ímpar
- 🧱 Leitura de distribuição por colunas e dúzias
- 🎯 Reconhecimento de setores da roleta (Voisins, Tier, Orphelins, Zero)
- 🔔 Alertas visuais e sonoros quando padrões se repetem
- 🌙 Tema escuro para melhor conforto visual
- 📱 Totalmente responsivo (funciona no celular, tablet e desktop)

---

## 📲 Como usar

1. Acesse: [https://SEU_USUARIO.github.io/roleta-pro](https://SEU_USUARIO.github.io/roleta-pro)
2. No iPhone, use Safari e toque em **"Compartilhar" → "Adicionar à Tela de Início"**
3. O app funcionará como um aplicativo instalado no celular

---

## 📦 Tecnologias usadas

- HTML5, CSS3, JavaScript
- OCR para leitura automática dos números
- GitHub Pages para hospedagem

---

## 📌 Observações

> ⚠️ Este projeto é apenas para fins de **análise estatística e educacional**.  
> Não garante ganhos e **não é afiliado ao Bet365**.

---

## 🧠 Desenvolvido por

**Roleta Pro Team**  
Suporte: [nenef285@gmail.com](mailto:nenef285@gmail.com)
